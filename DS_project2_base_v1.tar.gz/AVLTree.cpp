#include "AVLTree.h"

AVLTree::AVLTree(ofstream * flog)
{
}

AVLTree::~AVLTree()
{
}

AVLNode * AVLTree::Getroot()
{
	return NULL;
}

void AVLTree::Setroot(AVLNode * node)
{
}

bool AVLTree::Insert(CityData * node)
{
	return true;
}

CityData * AVLTree::Delete(int num)
{
	return NULL;
}

CityData * AVLTree::Search(int num)
{
	return NULL;
}

bool AVLTree::Print()
{
	return true;
}
