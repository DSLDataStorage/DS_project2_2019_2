#include "Graph.h"
#include <map>

Graph::Graph(ofstream * flog)
{
}

Graph::~Graph()
{
}

bool Graph::Build(AVLTree * root)
{
	return false;
}

void Graph::Print_GP()
{
}

void Graph::Print_MST()
{
}

bool Graph::Kruskal()
{
	return false;
}

void Graph::make_set()
{
}

void Graph::union_set(int x, int y)
{
}

void Graph::find(int x)
{
}
