#include "AVLNode.h"

AVLNode::AVLNode()
{
}

AVLNode::~AVLNode()
{
}

CityData * AVLNode::GetCityData()
{
	return NULL;
}

AVLNode * AVLNode::GetLeft()
{
	return NULL;
}

AVLNode * AVLNode::GetRight()
{
	return NULL;
}

int AVLNode::GetmBF()
{
	return 0;
}

void AVLNode::SetCityData(CityData * node)
{
}

void AVLNode::SetLeft(AVLNode * node)
{
}

void AVLNode::SetRight(AVLNode * node)
{
}

void AVLNode::SetmBF(int n)
{
}
